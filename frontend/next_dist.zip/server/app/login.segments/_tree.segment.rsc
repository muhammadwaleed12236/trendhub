:HL["/_next/static/css/b7091a2f5e562beb.css","style"]
:HL["/_next/static/css/0e80944ff3c0960d.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"login","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"FteRI7iseCX_PpmbCwPtF"}
