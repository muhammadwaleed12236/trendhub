1:"$Sreact.fragment"
2:I[484,[],"ViewportBoundary"]
3:I[484,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[6869,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"TrendHub | Premium Fashion Clothing Brand"}],["$","meta","1",{"name":"description","content":"Experience modern luxury with TrendHub's clean, minimalist fashion collection. High-end apparel designed for timeless elegance."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?603d046c9a6fdfbb","type":"image/x-icon","sizes":"16x16"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"C_ep_q5nrM53MODPNzj7J"}
