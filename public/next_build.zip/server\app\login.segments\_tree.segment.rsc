:HL["/_next/static/css/5824ea2fc44eb6c5.css","style"]
:HL["/_next/static/css/06c15986e81257a6.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"login","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"C_ep_q5nrM53MODPNzj7J"}
